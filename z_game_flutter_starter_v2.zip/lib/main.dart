import 'package:flutter/material.dart';

void main() => runApp(const ZGameApp());

const bg = Color(0xFF170608);
const panel = Color(0xFF351018);
const gold = Color(0xFFFFD45C);
const cream = Color(0xFFFFF2D2);

class ZGameApp extends StatelessWidget {
  const ZGameApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Z Game Demo',
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: bg,
          colorScheme: ColorScheme.fromSeed(
            seedColor: gold,
            brightness: Brightness.dark,
          ),
          useMaterial3: true,
        ),
        home: const HomePage(),
      );
}

class GameItem {
  final String title;
  final String category;
  final IconData icon;
  final Color color;
  const GameItem(this.title, this.category, this.icon, this.color);
}

const gameItems = <GameItem>[
  GameItem('Lucky Tiles', 'HOT', Icons.grid_view_rounded, Color(0xFF8E2E22)),
  GameItem('Evolution Match', 'CASUAL', Icons.auto_awesome, Color(0xFF56313D)),
  GameItem('Sky Pilot Demo', 'ARCADE', Icons.flight_takeoff, Color(0xFF263B55)),
  GameItem('Fortune Gems', 'HOT', Icons.diamond, Color(0xFF8B5A13)),
  GameItem('Cricket Stars', 'SPORTS', Icons.sports_cricket, Color(0xFF24543D)),
  GameItem('Rocket Run', 'ARCADE', Icons.rocket_launch, Color(0xFF6D263B)),
  GameItem('Jewel Quest', 'CASUAL', Icons.workspace_premium, Color(0xFF365A65)),
  GameItem('Puzzle World', 'PUZZLE', Icons.extension, Color(0xFF5C3B74)),
  GameItem('Golden Memory', 'PUZZLE', Icons.lightbulb, Color(0xFF79531D)),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  int tab = 0;
  String category = 'ALL';
  late final AnimationController pulse = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1100),
  )..repeat(reverse: true);

  @override
  void dispose() {
    pulse.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final filtered = gameItems.where((g) =>
        category == 'ALL' || g.category == category).toList();

    return Scaffold(
      body: SafeArea(
        child: IndexedStack(
          index: tab,
          children: [
            _home(filtered),
            _simplePage('Promotions', Icons.local_offer, 'Demo offers and announcements'),
            _simplePage('All Games', Icons.sports_esports, 'Choose a casual game to preview'),
            _simplePage('Earn Points', Icons.card_giftcard, 'Collect virtual demo points'),
            _simplePage('My Profile', Icons.person, 'Guest Player  •  VIP 0'),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF650B18),
        indicatorColor: const Color(0xFF8D2636),
        selectedIndex: tab,
        onDestinationSelected: (value) => setState(() => tab = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: 'HOME'),
          NavigationDestination(icon: Icon(Icons.percent), label: 'PROMO'),
          NavigationDestination(icon: Icon(Icons.sports_esports), label: 'GAMES'),
          NavigationDestination(icon: Icon(Icons.card_giftcard), label: 'EARN'),
          NavigationDestination(icon: Icon(Icons.person), label: 'MINE'),
        ],
      ),
    );
  }

  Widget _home(List<GameItem> filtered) => CustomScrollView(
        slivers: [
          SliverToBoxAdapter(child: _header()),
          SliverToBoxAdapter(child: _promo()),
          SliverToBoxAdapter(child: _announcement()),
          SliverToBoxAdapter(child: _profile()),
          SliverToBoxAdapter(child: _sectionTitle('Explore games')),
          SliverToBoxAdapter(child: _categoryPicker()),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 22),
            sliver: SliverGrid(
              delegate: SliverChildBuilderDelegate(
                (context, index) => _gameCard(filtered[index], index),
                childCount: filtered.length,
              ),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                mainAxisSpacing: 14,
                crossAxisSpacing: 12,
                childAspectRatio: .78,
              ),
            ),
          ),
        ],
      );

  Widget _header() => Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
        child: Row(children: [
          const Text('Z', style: TextStyle(
            color: Color(0xFFFF4D59), fontSize: 30,
            fontWeight: FontWeight.w900, fontStyle: FontStyle.italic)),
          const SizedBox(width: 7),
          const Expanded(child: Text('Z GAME',
            style: TextStyle(color: gold, fontSize: 22,
              fontWeight: FontWeight.w900, letterSpacing: 1.2))),
          _headerIcon(Icons.support_agent),
          _headerIcon(Icons.mail_outline),
          _headerIcon(Icons.card_giftcard),
        ]),
      );

  Widget _headerIcon(IconData icon) => Padding(
        padding: const EdgeInsets.only(left: 13),
        child: Icon(icon, color: cream, size: 25),
      );

  Widget _promo() => AnimatedBuilder(
        animation: pulse,
        builder: (context, child) => Container(
          margin: const EdgeInsets.symmetric(horizontal: 14),
          padding: const EdgeInsets.all(17),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: const LinearGradient(
              colors: [Color(0xFF651B27), Color(0xFF18080D), Color(0xFF49202A)],
              begin: Alignment.topLeft, end: Alignment.bottomRight),
            border: Border.all(
              color: Color.lerp(const Color(0xFF70402E), gold, pulse.value)!,
            ),
            boxShadow: [
              BoxShadow(
                color: gold.withOpacity(.08 + pulse.value * .12),
                blurRadius: 12 + pulse.value * 8,
              ),
            ],
          ),
          child: Row(children: [
            const CircleAvatar(
              radius: 31, backgroundColor: Color(0xFF8D4C28),
              child: Icon(Icons.stars, color: gold, size: 34)),
            const SizedBox(width: 12),
            const Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('WELCOME BONUS', style: TextStyle(
                  color: gold, fontSize: 18, fontWeight: FontWeight.w900)),
                SizedBox(height: 4),
                Text('Enjoy free casual games',
                  style: TextStyle(color: cream, fontSize: 12)),
              ],
            )),
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFF9E2944),
                foregroundColor: Colors.white,
              ),
              onPressed: () => _message('Welcome to Z Game Demo!'),
              child: const Text('PLAY'),
            ),
          ]),
        ),
      );

  Widget _announcement() => Container(
        margin: const EdgeInsets.fromLTRB(14, 14, 14, 8),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
        decoration: BoxDecoration(
          color: panel, borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFF8D4B35))),
        child: const Row(children: [
          Icon(Icons.campaign, color: gold, size: 20),
          SizedBox(width: 9),
          Expanded(child: Text(
            'Welcome! Play with virtual points only.',
            style: TextStyle(color: cream, fontSize: 12))),
        ]),
      );

  Widget _profile() => Container(
        margin: const EdgeInsets.fromLTRB(14, 8, 14, 8),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color(0xFF240B10),
          borderRadius: BorderRadius.circular(15)),
        child: Row(children: [
          const CircleAvatar(
            radius: 25, backgroundColor: Color(0xFF6A3B32),
            child: Icon(Icons.person, color: cream, size: 29)),
          const SizedBox(width: 12),
          const Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Guest Player', style: TextStyle(color: cream, fontSize: 15)),
              SizedBox(height: 4),
              Text('⭐ 5,000 virtual points', style: TextStyle(
                color: gold, fontSize: 14, fontWeight: FontWeight.bold)),
            ],
          )),
          const Column(children: [
            Icon(Icons.stars, color: gold, size: 25),
            SizedBox(height: 3),
            Text('VIP 0', style: TextStyle(color: cream, fontSize: 10)),
          ]),
        ]),
      );

  Widget _sectionTitle(String title) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
        child: Text(title, style: const TextStyle(
          color: gold, fontSize: 18, fontWeight: FontWeight.bold)),
      );

  Widget _categoryPicker() {
    const labels = ['ALL', 'HOT', 'CASUAL', 'ARCADE', 'SPORTS', 'PUZZLE'];
    return SizedBox(
      height: 43,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        scrollDirection: Axis.horizontal,
        itemCount: labels.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final label = labels[index];
          final selected = category == label;
          return ChoiceChip(
            label: Text(label),
            selected: selected,
            onSelected: (_) => setState(() => category = label),
            selectedColor: const Color(0xFF8D2636),
            backgroundColor: panel,
            labelStyle: TextStyle(
              color: selected ? gold : cream,
              fontWeight: FontWeight.bold,
              fontSize: 11),
            side: const BorderSide(color: Color(0xFF70402E)),
          );
        },
      ),
    );
  }

  Widget _gameCard(GameItem game, int index) => TweenAnimationBuilder<double>(
        tween: Tween(begin: .88, end: 1),
        duration: Duration(milliseconds: 250 + (index % 4) * 100),
        curve: Curves.easeOutBack,
        builder: (context, scale, child) => Transform.scale(
          scale: scale, child: child),
        child: InkWell(
          borderRadius: BorderRadius.circular(13),
          onTap: () => _message('${game.title} demo selected'),
          child: Column(children: [
            Expanded(child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(13),
                gradient: LinearGradient(
                  colors: [game.color, const Color(0xFF210A10)],
                  begin: Alignment.topLeft, end: Alignment.bottomRight),
                border: Border.all(color: const Color(0xFF70402E))),
              child: Stack(children: [
                const Positioned(right: 7, top: 7,
                  child: Icon(Icons.auto_awesome, color: gold, size: 17)),
                Center(child: Icon(game.icon, color: gold, size: 48)),
              ]),
            )),
            const SizedBox(height: 6),
            Text(game.title, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: cream, fontSize: 11)),
          ]),
        ),
      );

  Widget _simplePage(String title, IconData icon, String subtitle) => Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, color: gold, size: 66),
            const SizedBox(height: 16),
            Text(title, style: const TextStyle(
              color: gold, fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(subtitle, textAlign: TextAlign.center,
              style: const TextStyle(color: cream)),
            const SizedBox(height: 20),
            const Text('Demo screen — virtual points only',
              style: TextStyle(color: Colors.white54, fontSize: 12)),
          ]),
        ),
      );

  void _message(String text) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(text), duration: const Duration(seconds: 2)));
  }
}
