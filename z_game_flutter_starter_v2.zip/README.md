# Z Game Demo — Flutter starter

A dark red-and-gold casual game hub UI inspired by the user's reference layout.

## Included
- Home screen with promotional banner, announcement and guest profile
- Category chips that filter the game tiles
- Animated promo glow and game-card entrance
- Bottom navigation with demo screens
- Virtual demo points only

## Safety and scope
This is a casual-game UI prototype. It has no deposits, withdrawals, cash prizes, betting, or real-money gambling. The game tiles are placeholders and show a demo message.

## Run
1. Install Flutter SDK and Android Studio.
2. In this folder, run `flutter pub get`.
3. Run `flutter run`.

## Build APK
Run `flutter build apk --release`.
The APK is generated at `build/app/outputs/flutter-apk/app-release.apk`.

Note: This environment does not have the Flutter SDK installed, so this package contains the source project, not a compiled APK.
